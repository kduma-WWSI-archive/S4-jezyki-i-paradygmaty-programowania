namespace Zadanie1
{
    partial class EditEmployeeWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TBImie = new System.Windows.Forms.TextBox();
            this.TBMiasto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TBNazwisko = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TBPensja = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TBPesel = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TBStanowisko = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TBUlica = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BZapisz = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Imie";
            // 
            // TBImie
            // 
            this.TBImie.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBImie.Location = new System.Drawing.Point(95, 17);
            this.TBImie.Name = "TBImie";
            this.TBImie.Size = new System.Drawing.Size(126, 20);
            this.TBImie.TabIndex = 1;
            // 
            // TBMiasto
            // 
            this.TBMiasto.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBMiasto.Location = new System.Drawing.Point(95, 43);
            this.TBMiasto.Name = "TBMiasto";
            this.TBMiasto.Size = new System.Drawing.Size(126, 20);
            this.TBMiasto.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Miasto";
            // 
            // TBNazwisko
            // 
            this.TBNazwisko.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBNazwisko.Location = new System.Drawing.Point(95, 69);
            this.TBNazwisko.Name = "TBNazwisko";
            this.TBNazwisko.Size = new System.Drawing.Size(126, 20);
            this.TBNazwisko.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nazwisko";
            // 
            // TBPensja
            // 
            this.TBPensja.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBPensja.Location = new System.Drawing.Point(95, 95);
            this.TBPensja.Name = "TBPensja";
            this.TBPensja.Size = new System.Drawing.Size(126, 20);
            this.TBPensja.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Pensja";
            // 
            // TBPesel
            // 
            this.TBPesel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBPesel.Location = new System.Drawing.Point(95, 121);
            this.TBPesel.Name = "TBPesel";
            this.TBPesel.Size = new System.Drawing.Size(126, 20);
            this.TBPesel.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Pesel";
            // 
            // TBStanowisko
            // 
            this.TBStanowisko.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBStanowisko.Location = new System.Drawing.Point(95, 147);
            this.TBStanowisko.Name = "TBStanowisko";
            this.TBStanowisko.Size = new System.Drawing.Size(126, 20);
            this.TBStanowisko.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Stanowisko";
            // 
            // TBUlica
            // 
            this.TBUlica.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBUlica.Location = new System.Drawing.Point(95, 173);
            this.TBUlica.Name = "TBUlica";
            this.TBUlica.Size = new System.Drawing.Size(126, 20);
            this.TBUlica.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 176);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Ulica";
            // 
            // BZapisz
            // 
            this.BZapisz.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BZapisz.Location = new System.Drawing.Point(95, 204);
            this.BZapisz.Name = "BZapisz";
            this.BZapisz.Size = new System.Drawing.Size(125, 26);
            this.BZapisz.TabIndex = 14;
            this.BZapisz.Text = "Zapisz";
            this.BZapisz.UseVisualStyleBackColor = true;
            this.BZapisz.Click += new System.EventHandler(this.BZapisz_Click);
            // 
            // EditEmployeeWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(234, 243);
            this.Controls.Add(this.BZapisz);
            this.Controls.Add(this.TBUlica);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TBStanowisko);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TBPesel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TBPensja);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TBNazwisko);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TBMiasto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TBImie);
            this.Controls.Add(this.label1);
            this.MaximumSize = new System.Drawing.Size(500, 281);
            this.MinimumSize = new System.Drawing.Size(250, 281);
            this.Name = "EditEmployeeWindow";
            this.Text = "Pracownik";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBImie;
        private System.Windows.Forms.TextBox TBMiasto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBNazwisko;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TBPensja;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TBPesel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TBStanowisko;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TBUlica;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BZapisz;
    }
}