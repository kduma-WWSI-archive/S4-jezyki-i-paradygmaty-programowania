using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// ReSharper disable LocalizableElement

namespace Zadanie1
{
    public class Pracownik
    {
        public string Imie { get; set; }

        public string Nazwisko { get; set; }
        
        public string Ulica { get; set; }
        
        public string Miasto { get; set; }
        
        public string Stanowisko { get; set; }
        
        public decimal Pensja { get; set; }

        private string _pesel;
        
        public string Pesel
        {
            get { return _pesel; }
            set
            {
                long result;
                
                if (value.Length == 11 && long.TryParse(value, out result))
                {
                    _pesel = value;
                }
                else
                {
                    throw new Exception("Błąd Walidacji");
                }
            }
        }

        private Pracownik()
        {
            
        }

        public void Zapisz()
        {
            File.WriteAllText($"./dane/{_pesel}.txt", $"{Imie}\n{Nazwisko}\n{Miasto}\n{Ulica}\n{Pesel}\n{Stanowisko}\n{Pensja.ToString()}", Encoding.UTF8);
        }

        public static Pracownik Otworz(string pesel)
        {
            var dane = File.ReadAllLines($"./dane/{pesel}.txt", Encoding.UTF8);

            return new Pracownik
            {
                Imie = dane[0],
                Nazwisko = dane[1],
                Miasto = dane[2],
                Ulica = dane[3],
                _pesel = dane[4],
                Stanowisko = dane[5],
                Pensja = Convert.ToDecimal(dane[6])
            };
        }

        public override string ToString()
        {
            return $"{Imie} {Nazwisko}";
        }
    }
}
